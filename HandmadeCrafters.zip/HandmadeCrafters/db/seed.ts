import { db } from "./index";
import {
  categories,
  categoriesInsertSchema,
  knowledgeBase,
  knowledgeBaseInsertSchema,
  products,
  productInsertSchema,
  reviews,
  reviewInsertSchema,
} from "@shared/schema";
import { eq, and } from "drizzle-orm";

async function seed() {
  try {
    // Seed support categories
    const categoryData = [
      {
        name: "Chat Support",
        icon: "comment-dots",
        isActive: true,
      },
      {
        name: "Product Help",
        icon: "shopping-bag",
        isActive: true,
      },
      {
        name: "Customization",
        icon: "sliders-h",
        isActive: true,
      },
      {
        name: "Shipping & Delivery",
        icon: "truck",
        isActive: true,
      },
      {
        name: "Returns & Refunds",
        icon: "undo-alt",
        isActive: true,
      },
      {
        name: "Newsletter",
        icon: "envelope",
        isActive: true,
      },
    ];

    for (const category of categoryData) {
      const validCategory = categoriesInsertSchema.parse(category);
      const existingCategory = await db.query.categories.findFirst({
        where: eq(categories.name, category.name),
      });

      if (!existingCategory) {
        await db.insert(categories).values(validCategory);
        console.log(`Created category: ${category.name}`);
      } else {
        console.log(`Category ${category.name} already exists`);
      }
    }

    // Seed knowledge base entries
    const knowledgeBaseData = [
      {
        intent: "greeting",
        responses: [
          "Welcome to HandCrafted support! I'm here to help you with our handmade products, customization options, and newsletter subscriptions. What can I assist you with today?",
          "Hello! I'm the HandCrafted Assistant. How can I help you today with our handmade products or services?",
          "Greetings! I'm here to help with any questions about our handcrafted items. What would you like to know?"
        ],
        keywords: ["hello", "hi", "hey", "greetings", "howdy", "start", "begin"],
      },
      {
        intent: "product_info",
        responses: [
          "Our handcrafted products include wooden bowls, ceramic plates, textile products, jewelry, and gift sets. Each item is made by skilled artisans using traditional techniques. Would you like details on a specific product?",
          "We offer a variety of handmade products including wooden kitchenware, ceramics, textiles, and jewelry. Each piece is unique and crafted with care. Which product line are you interested in?",
          "HandCrafted specializes in artisanal goods made by skilled craftspeople. Our catalog includes wooden bowls, ceramic tableware, handwoven textiles, and artisanal jewelry. Would you like to know more about any specific collection?"
        ],
        keywords: ["products", "catalog", "items", "goods", "merchandise", "sell", "offer", "collection"],
      },
      {
        intent: "wooden_bowl",
        responses: [
          "Great choice! Our hand-carved wooden bowls come with several customization options: Choice of wood (maple, walnut, cherry, or oak), Size options (small, medium, or large), Custom engraving or inlay designs, and Finishing options (natural oil, beeswax, or lacquer). Would you like me to show you some examples?",
          "Our wooden bowls are our most popular items! You can customize the wood type (maple, walnut, cherry, oak), size, add personalized engravings, and choose your preferred finish. Would you like to see some examples from our collection?",
          "The wooden bowls are handcrafted from sustainable hardwoods. Each bowl can be customized with your choice of wood, size, personalized engravings, and finish type. Would you like to explore some recent designs our artisans have created?"
        ],
        keywords: ["wooden bowl", "wood bowl", "carved bowl", "bowl customization", "wood options", "engraving"],
      },
      {
        intent: "customization",
        responses: [
          "We offer various customization options for our products. For wooden items, you can choose the wood type, size, add engravings, and select a finish. For ceramics, you can select colors, patterns, and glazes. For textiles, you can choose fabrics, colors, and embroidery designs. What would you like to customize?",
          "Customization is one of our specialties! Depending on the product, you can personalize the materials, dimensions, colors, patterns, and add custom text or designs. Which product would you like to customize?",
          "Our customization options let you create truly personal pieces. You can select materials, dimensions, add engravings or monograms, and choose from various finishes. What kind of item are you looking to customize?"
        ],
        keywords: ["customize", "personalize", "custom", "personalization", "options", "tailor", "bespoke", "unique", "engraving"],
      },
      {
        intent: "pricing",
        responses: [
          "Our products are priced based on materials, size, and customization complexity. Wooden bowls start at $59.99, ceramic plates from $39.99, textile products from $29.99, and jewelry from $49.99. For a specific quote on a custom piece, please provide more details about what you're looking for.",
          "Pricing depends on the product type, materials, and level of customization. Basic wooden bowls start at $59.99, with custom engravings adding $15-30 depending on complexity. Would you like pricing for a specific item?",
          "Our handcrafted items range from $29.99 for simple textile products to $150+ for intricately designed wooden pieces with custom inlays. The price reflects the craftsmanship, quality materials, and customization work. What product are you interested in?"
        ],
        keywords: ["price", "cost", "pricing", "how much", "expensive", "affordable", "budget", "dollars", "pay"],
      },
      {
        intent: "shipping",
        responses: [
          "We offer standard shipping (5-7 business days) for $8.99 and expedited shipping (2-3 business days) for $14.99. International shipping is available at variable rates. Custom orders may take 1-2 weeks of production time before shipping. Would you like more information about our shipping policies?",
          "For domestic orders, we provide standard shipping (5-7 days) and expedited options (2-3 days). Shipping costs start at $8.99. For custom orders, please allow additional production time before shipping. Would you like to know about international shipping options?",
          "We ship nationwide with delivery times ranging from 2-7 business days depending on your selected shipping method. Rates start at $8.99. For custom pieces, please allow 1-2 weeks of production time in addition to shipping time. Can I help with any specific shipping questions?"
        ],
        keywords: ["shipping", "delivery", "ship", "mail", "send", "postage", "courier", "receive", "tracking"],
      },
      {
        intent: "returns",
        responses: [
          "We accept returns within 30 days of delivery for standard products in original condition. For custom items, we can offer store credit or address quality issues, but cannot accept returns due to the personalized nature. Please contact us with your order number to initiate a return process.",
          "Our return policy allows returns within 30 days for standard products. Custom items cannot be returned unless there's a quality issue. All returns should be in original condition with packaging. Would you like help initiating a return?",
          "For standard products, we offer a 30-day return window. Please note that customized items cannot be returned unless there is a manufacturing defect. Would you like me to explain the return process or address a specific return issue?"
        ],
        keywords: ["return", "refund", "money back", "exchange", "send back", "cancel order", "wrong item"],
      },
      {
        intent: "newsletter",
        responses: [
          "Our newsletter subscribers receive exclusive benefits including early access to new products, special discounts (including 15% off your first order), artisan stories, and customization inspirations. Would you like to subscribe to our newsletter?",
          "By joining our newsletter, you'll get 15% off your first purchase, early access to new collections, exclusive subscriber-only offers, and inspiring content about our artisans and their craft. Would you like to sign up now?",
          "Newsletter subscribers enjoy special perks like exclusive discounts, first access to limited edition pieces, behind-the-scenes content about our artisans, and seasonal style guides. Plus, you'll get 15% off your first order when you sign up. Would you like to subscribe?"
        ],
        keywords: ["newsletter", "subscribe", "email list", "updates", "subscription", "mailing list", "discount", "offers"],
      },
      {
        intent: "thanks",
        responses: [
          "You're welcome! I'm glad I could help. Is there anything else you'd like to know about our handcrafted products?",
          "My pleasure! If you have any other questions about our handmade products or services, feel free to ask.",
          "Happy to help! Let me know if you need any other information about our handcrafted items or customization options."
        ],
        keywords: ["thanks", "thank you", "appreciate", "helpful", "great", "good job"],
      },
      {
        intent: "goodbye",
        responses: [
          "Thank you for chatting with HandCrafted support. Have a wonderful day, and we hope to craft something special for you soon!",
          "It was a pleasure assisting you today. If you need anything else, don't hesitate to reach out. Have a great day!",
          "Thank you for your interest in HandCrafted products. We're here whenever you need more information. Have a wonderful day!"
        ],
        keywords: ["bye", "goodbye", "see you", "farewell", "end", "finish", "done", "that's all"],
      },
      {
        intent: "fallback",
        responses: [
          "I'm sorry, I didn't quite understand that. Could you rephrase your question about our handcrafted products or customization options?",
          "I apologize, but I'm not sure I understood your question. Could you provide more details or ask in a different way?",
          "I'm still learning and didn't catch that. Could you ask your question about our handmade products in a different way? Alternatively, you can type 'human' to connect with a customer service representative."
        ],
        keywords: [],
      },
    ];

    for (const entry of knowledgeBaseData) {
      const validEntry = knowledgeBaseInsertSchema.parse(entry);
      const existingEntry = await db.query.knowledgeBase.findFirst({
        where: eq(knowledgeBase.intent, entry.intent),
      });

      if (!existingEntry) {
        await db.insert(knowledgeBase).values(validEntry);
        console.log(`Created knowledge base entry: ${entry.intent}`);
      } else {
        console.log(`Knowledge base entry ${entry.intent} already exists`);
      }
    }

    // Seed products
    const productData = [
      {
        name: "Handcrafted Wooden Bowls",
        description: "Each bowl is handcrafted from sustainably sourced wood. Perfect for serving or decorative use.",
        price: "$59.99",
        image: "https://images.unsplash.com/photo-1578010504973-cf221701fbf6?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        rating: "4.7",
        reviewCount: 128,
      },
      {
        name: "Ceramic Serving Plates",
        description: "Handmade ceramic plates with unique glazes. Each piece has subtle variations making it one of a kind.",
        price: "$49.99",
        image: "https://images.unsplash.com/photo-1567336273898-ebbf9eb3c3bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        rating: "4.5",
        reviewCount: 94,
      },
      {
        name: "Handwoven Textile Products",
        description: "Artisanal textiles created using traditional weaving techniques. Sustainable and ethically produced.",
        price: "$39.99",
        image: "https://images.unsplash.com/photo-1583484963886-cfe2bff2945f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        rating: "4.8",
        reviewCount: 76,
      },
    ];

    for (const product of productData) {
      const validProduct = productInsertSchema.parse(product);
      const existingProduct = await db.query.products.findFirst({
        where: eq(products.name, product.name),
      });

      if (!existingProduct) {
        await db.insert(products).values(validProduct);
        console.log(`Created product: ${product.name}`);
      } else {
        console.log(`Product ${product.name} already exists`);
      }
    }

    // Get products to reference in reviews
    const seededProducts = await db.query.products.findMany();
    
    // Seed reviews
    const reviewData = [
      {
        productId: seededProducts.find(p => p.name === "Handcrafted Wooden Bowls")?.id || 1,
        username: "Emma T.",
        rating: 5,
        content: "The custom engraving on my walnut bowl is absolutely beautiful! It makes for a perfect wedding gift.",
        image: "https://images.unsplash.com/photo-1578010504973-cf221701fbf6?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&h=100&q=80",
        verifiedPurchase: true,
        timestamp: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000), // 2 weeks ago
      },
      {
        productId: seededProducts.find(p => p.name === "Handcrafted Wooden Bowls")?.id || 1,
        username: "Marcus W.",
        rating: 4,
        content: "The quality of the wood is excellent. I ordered the medium size and it's perfect for serving snacks.",
        verifiedPurchase: true,
        timestamp: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 1 month ago
      },
      {
        productId: seededProducts.find(p => p.name === "Handcrafted Wooden Bowls")?.id || 1,
        username: "Sarah K.",
        rating: 5,
        content: "Newsletter subscriber benefit was great - got 15% off my custom bowl. The customer service was fantastic when I had questions.",
        verifiedPurchase: true,
        timestamp: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000), // 2 months ago
      },
      {
        productId: seededProducts.find(p => p.name === "Ceramic Serving Plates")?.id || 2,
        username: "James L.",
        rating: 5,
        content: "These plates are even more beautiful in person. The glazing is spectacular and every piece is truly unique.",
        verifiedPurchase: true,
        timestamp: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 1 week ago
      },
      {
        productId: seededProducts.find(p => p.name === "Ceramic Serving Plates")?.id || 2,
        username: "Michelle D.",
        rating: 4,
        content: "Excellent craftsmanship. The only reason for 4 stars is that the color was slightly different than pictured.",
        verifiedPurchase: true,
        timestamp: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000), // 45 days ago
      },
      {
        productId: seededProducts.find(p => p.name === "Handwoven Textile Products")?.id || 3,
        username: "David T.",
        rating: 5,
        content: "The table runner I ordered is absolutely beautiful. The colors are vibrant and the craftsmanship is exceptional.",
        verifiedPurchase: true,
        timestamp: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), // 10 days ago
      },
    ];

    for (const review of reviewData) {
      if (!review.productId) continue;
      
      const validReview = reviewInsertSchema.parse(review);
      
      // Check if review exists (using combination of username and product)
      const existingReview = await db.query.reviews.findFirst({
        where: and(
          eq(reviews.productId, review.productId),
          eq(reviews.username, review.username)
        ),
      });

      if (!existingReview) {
        await db.insert(reviews).values(validReview);
        console.log(`Created review by ${review.username}`);
      } else {
        console.log(`Review by ${review.username} for this product already exists`);
      }
    }

    console.log("Database seeded successfully");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
