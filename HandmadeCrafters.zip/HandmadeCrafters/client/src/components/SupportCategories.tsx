import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { X } from 'lucide-react';
import { useChatContext } from '@/context/ChatContext';
import { Category } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { useMobile } from '@/hooks/use-mobile';

interface SupportCategoriesProps {
  onClose: () => void;
}

export default function SupportCategories({ onClose }: SupportCategoriesProps) {
  const { selectedCategory, setSelectedCategory, sendFeedback } = useChatContext();
  const isMobile = useMobile();
  const [satisfaction, setSatisfaction] = React.useState<number | null>(null);

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const getIconClass = (icon: string) => {
    return `fas fa-${icon}`;
  };

  const handleCategoryClick = (category: Category) => {
    setSelectedCategory(category);
  };

  const handleFeedback = (rating: number) => {
    setSatisfaction(rating);
    sendFeedback(rating);
  };

  return (
    <div className="bg-white rounded-lg shadow p-4 sticky top-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">Support Categories</h2>
        {isMobile && (
          <Button variant="ghost" size="icon" onClick={onClose} className="lg:hidden">
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Category Navigation */}
      <nav className="space-y-2">
        {categories.map((category) => (
          <a
            key={category.id}
            href="#"
            className={`flex items-center p-3 rounded-lg ${
              selectedCategory?.id === category.id
                ? 'bg-primary bg-opacity-10 text-primary border-l-4 border-primary'
                : 'hover:bg-gray-100 text-gray-700'
            }`}
            onClick={(e) => {
              e.preventDefault();
              handleCategoryClick(category);
            }}
          >
            <i className={`${getIconClass(category.icon)} mr-3`}></i>
            <span>{category.name}</span>
          </a>
        ))}
      </nav>

      {/* Customer Satisfaction */}
      <div className="mt-6 pt-6 border-t border-gray-200">
        <h3 className="text-sm font-medium text-gray-700 mb-2">How satisfied are you?</h3>
        <div className="flex space-x-2">
          <button
            className={`p-2 rounded-full hover:bg-gray-100 ${
              satisfaction === 1 ? 'text-yellow-500' : 'text-gray-400 hover:text-yellow-500'
            }`}
            onClick={() => handleFeedback(1)}
          >
            <i className="far fa-frown text-xl"></i>
          </button>
          <button
            className={`p-2 rounded-full hover:bg-gray-100 ${
              satisfaction === 2 ? 'text-yellow-500' : 'text-gray-400 hover:text-yellow-500'
            }`}
            onClick={() => handleFeedback(2)}
          >
            <i className="far fa-meh text-xl"></i>
          </button>
          <button
            className={`p-2 rounded-full hover:bg-gray-100 ${
              satisfaction === 3 ? 'text-yellow-500' : 'text-gray-400 hover:text-yellow-500'
            }`}
            onClick={() => handleFeedback(3)}
          >
            <i className="far fa-smile text-xl"></i>
          </button>
          <button
            className={`p-2 rounded-full hover:bg-gray-100 ${
              satisfaction === 4 ? 'text-yellow-500' : 'text-gray-400 hover:text-yellow-500'
            }`}
            onClick={() => handleFeedback(4)}
          >
            <i className="far fa-grin-stars text-xl"></i>
          </button>
        </div>
      </div>
    </div>
  );
}
