import React, { useEffect, useRef } from 'react';
import { useChatContext } from '@/context/ChatContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Paperclip, Send, Mic } from 'lucide-react';

export default function ChatInterface() {
  const {
    messages,
    isTyping,
    isLoadingMessages,
    messageInput,
    setMessageInput,
    sendMessage,
    connectToHuman,
  } = useChatContext();
  
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  // Focus input on component mount
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (messageInput.trim()) {
      sendMessage(messageInput.trim());
      setMessageInput('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <>
      {/* Chat Header */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center text-white">
              <i className="fas fa-robot"></i>
            </div>
            <div className="ml-3">
              <h2 className="font-medium">HandCrafted Assistant</h2>
              <div className="flex items-center">
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-secondary opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-secondary"></span>
                </span>
                <p className="text-xs text-gray-500 ml-2">Online | Typically replies in 1 min</p>
              </div>
            </div>
          </div>
          <div>
            <Button variant="ghost" size="icon">
              <i className="fas fa-ellipsis-v"></i>
            </Button>
          </div>
        </div>
      </div>

      {/* Chat History */}
      <div 
        ref={chatContainerRef}
        className="h-96 overflow-y-auto p-4 chat-container"
      >
        {isLoadingMessages ? (
          <div className="flex justify-center items-center h-full">
            <div className="loading-spinner">Loading...</div>
          </div>
        ) : (
          <>
            {messages.map((message) => (
              <div
                key={message.id}
                className={message.isBot ? 'bot-message' : 'user-message'}
              >
                {message.isBot ? (
                  <>
                    <div className="bot-avatar">
                      <i className="fas fa-robot text-sm"></i>
                    </div>
                    <div className="bot-message-content">
                      <p className="text-sm whitespace-pre-line">{message.content}</p>
                      {message.images && message.images.length > 0 && (
                        <div className="grid grid-cols-2 gap-2 mt-3">
                          {message.images.map((img, idx) => (
                            <div key={idx} className="rounded overflow-hidden">
                              <img
                                src={img.url}
                                alt={img.alt}
                                className="w-full h-auto object-cover"
                              />
                              <div className="text-xs p-1 bg-gray-200">{img.caption}</div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </>
                ) : (
                  <>
                    <div className="user-message-content">
                      <p className="text-sm">{message.content}</p>
                    </div>
                    <div className="user-avatar">
                      <i className="fas fa-user text-sm"></i>
                    </div>
                  </>
                )}
              </div>
            ))}

            {/* Typing indicator */}
            {isTyping && (
              <div className="bot-message">
                <div className="bot-avatar">
                  <i className="fas fa-robot text-sm"></i>
                </div>
                <div className="ml-2 bg-gray-100 px-4 py-2 rounded-lg rounded-tl-none inline-block">
                  <div className="typing-indicator">
                    <div></div>
                    <div></div>
                    <div></div>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Chat Input */}
      <div className="border-t border-gray-200 p-4">
        <form onSubmit={handleSubmit}>
          <div className="flex items-center">
            <Button 
              type="button" 
              variant="ghost" 
              size="icon" 
              className="text-gray-500 hover:text-gray-700"
              title="Attach a file"
            >
              <Paperclip className="h-5 w-5" />
            </Button>
            <div className="relative flex-1 mx-2">
              <Input
                ref={inputRef}
                type="text"
                className="w-full border border-gray-300 rounded-full py-2 pl-4 pr-10 focus:outline-none focus:border-primary"
                placeholder="Type your message..."
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                onKeyDown={handleKeyPress}
              />
              <Button
                type="submit"
                variant="ghost"
                size="icon"
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-primary"
                disabled={!messageInput.trim()}
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <Button 
              type="button" 
              variant="ghost" 
              size="icon" 
              className="text-gray-500 hover:text-gray-700"
              title="Voice message"
            >
              <Mic className="h-5 w-5" />
            </Button>
          </div>
        </form>
        <div className="text-xs text-gray-500 mt-2 px-2 flex items-center justify-between">
          <div>
            <span className="text-primary cursor-pointer hover:underline">See FAQ</span> or try asking about product customization, shipping, or newsletter benefits
          </div>
          <div>
            <button 
              onClick={connectToHuman}
              className="text-primary hover:underline"
            >
              Talk to human agent
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
