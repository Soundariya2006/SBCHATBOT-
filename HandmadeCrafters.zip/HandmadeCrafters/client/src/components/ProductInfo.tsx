import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Star, StarHalf, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Product, Review } from '@/lib/types';
import { useMobile } from '@/hooks/use-mobile';

interface ProductInfoProps {
  onClose: () => void;
}

export default function ProductInfo({ onClose }: ProductInfoProps) {
  const isMobile = useMobile();
  const [selectedProduct, setSelectedProduct] = React.useState<number>(1);
  const [email, setEmail] = React.useState('');

  // Fetch products
  const { data: products = [] } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  // Fetch reviews for selected product
  const { data: reviews = [] } = useQuery<Review[]>({
    queryKey: [`/api/products/${selectedProduct}/reviews`],
    enabled: !!selectedProduct,
  });

  // Get current product
  const currentProduct = products.find(p => p.id === selectedProduct) || products[0];

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      // Here we would handle newsletter subscription
      alert(`Thank you for subscribing with ${email}!`);
      setEmail('');
    }
  };

  // Render star ratings
  const renderStars = (rating: string) => {
    const ratingNum = parseFloat(rating);
    const fullStars = Math.floor(ratingNum);
    const hasHalfStar = ratingNum % 1 >= 0.5;
    
    return (
      <div className="flex">
        {[...Array(fullStars)].map((_, i) => (
          <Star key={i} className="h-4 w-4 fill-yellow-500 text-yellow-500" />
        ))}
        {hasHalfStar && <StarHalf className="h-4 w-4 fill-yellow-500 text-yellow-500" />}
        {[...Array(5 - fullStars - (hasHalfStar ? 1 : 0))].map((_, i) => (
          <Star key={i + fullStars + (hasHalfStar ? 1 : 0)} className="h-4 w-4 text-yellow-500" />
        ))}
      </div>
    );
  };

  // Format date for reviews
  const formatDate = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays <= 7) return `${diffDays} days ago`;
    if (diffDays <= 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    if (diffDays <= 365) return `${Math.floor(diffDays / 30)} months ago`;
    return `${Math.floor(diffDays / 365)} years ago`;
  };

  if (!currentProduct) return null;

  return (
    <>
      {/* Product Details */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-lg font-semibold">{currentProduct.name}</h2>
          {isMobile && (
            <Button variant="ghost" size="icon" onClick={onClose} className="lg:hidden">
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
        <img
          src={currentProduct.image}
          alt={currentProduct.name}
          className="w-full h-40 object-cover rounded-lg mb-3"
        />
        <div className="flex justify-between items-center mb-2">
          <div className="text-sm font-medium">Starting from</div>
          <div className="text-lg font-semibold">{currentProduct.price}</div>
        </div>
        <p className="text-sm text-gray-600 mb-3">{currentProduct.description}</p>
        <div className="flex justify-between mb-2">
          {renderStars(currentProduct.rating)}
          <div className="text-sm text-gray-600">
            {currentProduct.rating} ({currentProduct.reviewCount} reviews)
          </div>
        </div>
        <Button className="w-full bg-secondary hover:bg-secondary-dark text-white py-2 rounded-lg mt-2 font-medium">
          Customize Now
        </Button>
      </div>

      {/* Customer Reviews */}
      <div className="bg-white rounded-lg shadow p-4">
        <h2 className="text-lg font-semibold mb-3">Customer Reviews</h2>

        {reviews.map((review) => (
          <div key={review.id} className="border-b border-gray-200 pb-3 mb-3">
            <div className="flex justify-between items-center mb-1">
              <div className="font-medium">{review.username}</div>
              <div className="flex">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                ))}
              </div>
            </div>
            <p className="text-sm text-gray-600 mb-1">{review.content}</p>
            {review.image && (
              <div className="flex">
                <img
                  src={review.image}
                  alt="Customer review photo"
                  className="w-12 h-12 object-cover rounded"
                />
              </div>
            )}
            <div className="text-xs text-gray-500 mt-1">
              Verified Purchase • {formatDate(review.timestamp)}
            </div>
          </div>
        ))}

        <a href="#" className="block text-center text-primary hover:underline text-sm mt-3">
          See all {currentProduct.reviewCount} reviews
        </a>
      </div>

      {/* Newsletter Promo */}
      <div className="bg-primary bg-opacity-10 rounded-lg p-4">
        <h3 className="text-primary font-medium mb-2">Join Our Newsletter</h3>
        <p className="text-sm text-gray-700 mb-3">
          Subscribe to receive exclusive offers, early access to new products, and 15% off your first
          order.
        </p>
        <form onSubmit={handleSubscribe}>
          <div className="flex">
            <Input
              type="email"
              className="flex-1 border border-r-0 border-gray-300 rounded-l-lg px-3 py-2 focus:outline-none focus:border-primary text-sm"
              placeholder="Your email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <Button
              type="submit"
              className="bg-primary text-white px-4 py-2 rounded-r-lg text-sm font-medium"
            >
              Subscribe
            </Button>
          </div>
        </form>
      </div>
    </>
  );
}
