import React from 'react';

export default function Footer() {
  return (
    <footer className="bg-white border-t border-gray-200 mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h2 className="text-lg font-semibold text-primary mb-4">HandCrafted</h2>
            <p className="text-gray-600 text-sm">Supporting artisans and bringing handmade quality to your home since 2010.</p>
            <div className="flex space-x-4 mt-4">
              <a href="#" className="text-gray-500 hover:text-primary">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="text-gray-500 hover:text-primary">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="text-gray-500 hover:text-primary">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-gray-500 hover:text-primary">
                <i className="fab fa-pinterest-p"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-gray-900 font-medium mb-4">Products</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="#" className="hover:text-primary">Wooden Bowls</a></li>
              <li><a href="#" className="hover:text-primary">Ceramic Plates</a></li>
              <li><a href="#" className="hover:text-primary">Textile Products</a></li>
              <li><a href="#" className="hover:text-primary">Jewelry</a></li>
              <li><a href="#" className="hover:text-primary">Gift Sets</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-gray-900 font-medium mb-4">Customer Service</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="#" className="hover:text-primary">Contact Us</a></li>
              <li><a href="#" className="hover:text-primary">FAQ</a></li>
              <li><a href="#" className="hover:text-primary">Shipping Policy</a></li>
              <li><a href="#" className="hover:text-primary">Returns & Refunds</a></li>
              <li><a href="#" className="hover:text-primary">Terms of Service</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-gray-900 font-medium mb-4">Get In Touch</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li className="flex items-start">
                <i className="fas fa-map-marker-alt mt-1 mr-2 text-primary"></i>
                <span>123 Artisan Way, Craftsville, CS 45678</span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-phone-alt mr-2 text-primary"></i>
                <span>(555) 123-4567</span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-envelope mr-2 text-primary"></i>
                <span>support@handcrafted.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-200 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-600">© {new Date().getFullYear()} HandCrafted. All rights reserved.</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <a href="#" className="text-sm text-gray-600 hover:text-primary">Privacy Policy</a>
            <a href="#" className="text-sm text-gray-600 hover:text-primary">Terms of Use</a>
            <a href="#" className="text-sm text-gray-600 hover:text-primary">Accessibility</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
