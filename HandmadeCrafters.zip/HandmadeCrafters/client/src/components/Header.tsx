import React from 'react';
import { Button } from '@/components/ui/button';
import { useMobile } from '@/hooks/use-mobile';
import { Menu, Search, ShoppingCart, User } from 'lucide-react';

interface HeaderProps {
  toggleCategories: () => void;
  toggleProductInfo: () => void;
}

export default function Header({ toggleCategories, toggleProductInfo }: HeaderProps) {
  const isMobile = useMobile();
  const [menuOpen, setMenuOpen] = React.useState(false);

  return (
    <header className="bg-white shadow">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <h1 className="text-2xl font-semibold text-primary">HandCrafted</h1>
          </div>
          
          <nav className={`${isMobile ? (menuOpen ? 'flex' : 'hidden') : 'hidden md:flex'} ${
            isMobile ? 'absolute top-16 left-0 right-0 z-50 flex-col space-y-2 p-4 bg-white shadow' : 'space-x-8'
          }`}>
            <a href="#" className="text-gray-700 hover:text-primary font-medium">Products</a>
            <a href="#" className="text-gray-700 hover:text-primary font-medium">Customization</a>
            <a href="#" className="text-gray-700 hover:text-primary font-medium">Reviews</a>
            <a href="#" className="text-gray-700 hover:text-primary font-medium">Newsletter</a>
            <a href="#" className="text-gray-700 hover:text-primary font-medium">Support</a>
          </nav>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="text-gray-700">
              <Search className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-gray-700 relative">
              <ShoppingCart className="h-5 w-5" />
              <span className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">3</span>
            </Button>
            <Button variant="ghost" size="icon" className="text-gray-700" onClick={toggleProductInfo}>
              <User className="h-5 w-5" />
            </Button>
            
            {isMobile && (
              <>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-gray-700" 
                  onClick={toggleCategories}
                >
                  <i className="fas fa-list"></i>
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="md:hidden text-gray-700"
                  onClick={() => setMenuOpen(!menuOpen)}
                >
                  <Menu className="h-5 w-5" />
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
