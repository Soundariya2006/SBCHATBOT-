import React, { createContext, useState, useContext, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { nanoid } from 'nanoid';
import { apiRequest } from '@/lib/queryClient';
import { Category, Message, ChatMessage, ChatContextType } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';

// Create the context
const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // State for chat
  const [sessionId, setSessionId] = useState<string>('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [messageInput, setMessageInput] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);

  // Generate a session ID on first load
  useEffect(() => {
    const storedSessionId = localStorage.getItem('chat_session_id');
    if (storedSessionId) {
      setSessionId(storedSessionId);
    } else {
      const newSessionId = nanoid();
      localStorage.setItem('chat_session_id', newSessionId);
      setSessionId(newSessionId);
    }
  }, []);

  // Fetch messages if session ID exists
  const { data: messageHistory, isLoading: isLoadingMessages } = useQuery({
    queryKey: [`/api/messages/${sessionId}`],
    enabled: !!sessionId,
    onSuccess: (data: Message[]) => {
      // Transform the data to match ChatMessage type
      const chatMessages: ChatMessage[] = data.map(msg => ({
        id: msg.id.toString(),
        content: msg.content,
        isBot: msg.isBot,
        timestamp: new Date(msg.timestamp).toISOString(),
      }));
      
      setMessages(chatMessages);
      
      // If no messages, send a welcome message
      if (data.length === 0) {
        sendWelcomeMessage();
      }
    },
    onError: (error) => {
      console.error('Error fetching messages:', error);
      toast({
        title: 'Error',
        description: 'Failed to load chat history. Please try again later.',
        variant: 'destructive',
      });
    },
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      return apiRequest('POST', '/api/messages', {
        sessionId,
        content,
      });
    },
    onSuccess: async (response) => {
      const data = await response.json();
      
      // Add user message to state
      const userMessage: ChatMessage = {
        id: data.userMessage.id.toString(),
        content: data.userMessage.content,
        isBot: false,
        timestamp: new Date().toISOString(),
      };
      
      // Show the user message immediately
      setMessages(prev => [...prev, userMessage]);
      
      // Show typing indicator
      setIsTyping(true);
      
      // Simulate a delay before showing the bot response
      setTimeout(() => {
        // Add bot message to state
        const botMessage: ChatMessage = {
          id: data.botMessage.id.toString(),
          content: data.botMessage.content,
          isBot: true,
          timestamp: new Date().toISOString(),
        };
        
        setMessages(prev => [...prev, botMessage]);
        setIsTyping(false);
        
        // Invalidate the query to refresh the chat history
        queryClient.invalidateQueries({ queryKey: [`/api/messages/${sessionId}`] });
      }, 1500);
    },
    onError: (error) => {
      console.error('Error sending message:', error);
      setIsTyping(false);
      toast({
        title: 'Error',
        description: 'Failed to send message. Please try again.',
        variant: 'destructive',
      });
    },
  });

  // Send welcome message
  const sendWelcomeMessage = async () => {
    try {
      // Simulate a typing indicator
      setIsTyping(true);
      
      setTimeout(() => {
        const welcomeMessage: ChatMessage = {
          id: nanoid(),
          content: "Welcome to HandCrafted support! I'm here to help you with our handmade products, customization options, and newsletter subscriptions. What can I assist you with today?",
          isBot: true,
          timestamp: new Date().toISOString(),
        };
        
        setMessages([welcomeMessage]);
        setIsTyping(false);
      }, 1000);
    } catch (error) {
      console.error('Error sending welcome message:', error);
      setIsTyping(false);
    }
  };

  // Send message function
  const sendMessage = (content: string) => {
    if (!sessionId || !content.trim()) return;
    
    sendMessageMutation.mutate(content);
  };

  // Connect to human agent
  const connectToHuman = () => {
    toast({
      title: 'Human Agent Requested',
      description: 'A customer support representative will contact you shortly.',
    });
    
    // Add message to chat
    const systemMessage: ChatMessage = {
      id: nanoid(),
      content: "I've requested a human agent for you. A customer support representative will join this conversation shortly. Please stay in the chat.",
      isBot: true,
      timestamp: new Date().toISOString(),
    };
    
    setMessages(prev => [...prev, systemMessage]);
  };

  // Send feedback
  const feedbackMutation = useMutation({
    mutationFn: async (rating: number) => {
      // Find the last bot message to attach feedback to
      const lastBotMessage = [...messages].reverse().find(msg => msg.isBot);
      if (!lastBotMessage) return null;
      
      return apiRequest('POST', '/api/feedback', {
        messageId: parseInt(lastBotMessage.id, 10),
        rating,
      });
    },
    onSuccess: () => {
      toast({
        title: 'Thank You!',
        description: 'Your feedback has been recorded.',
      });
    },
    onError: (error) => {
      console.error('Error sending feedback:', error);
      toast({
        title: 'Error',
        description: 'Failed to submit feedback. Please try again.',
        variant: 'destructive',
      });
    },
  });

  const sendFeedback = (rating: number) => {
    feedbackMutation.mutate(rating);
  };

  const contextValue: ChatContextType = {
    sessionId,
    messages,
    isTyping,
    isLoadingMessages,
    messageInput,
    setMessageInput,
    selectedCategory,
    setSelectedCategory,
    sendMessage,
    connectToHuman,
    sendFeedback,
  };

  return <ChatContext.Provider value={contextValue}>{children}</ChatContext.Provider>;
};

// Custom hook to use the chat context
export const useChatContext = () => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error('useChatContext must be used within a ChatProvider');
  }
  return context;
};
