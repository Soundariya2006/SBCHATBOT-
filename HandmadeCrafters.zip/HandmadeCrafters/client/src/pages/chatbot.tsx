import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import SupportCategories from '@/components/SupportCategories';
import ChatInterface from '@/components/ChatInterface';
import ProductInfo from '@/components/ProductInfo';
import { useMobile } from '@/hooks/use-mobile';

export default function ChatBot() {
  const isMobile = useMobile();
  const [showCategories, setShowCategories] = React.useState(!isMobile);
  const [showProductInfo, setShowProductInfo] = React.useState(!isMobile);

  // Toggle sidebar visibility on mobile
  const toggleCategories = () => {
    if (isMobile) {
      setShowCategories(prev => !prev);
      if (!showCategories) setShowProductInfo(false);
    }
  };

  const toggleProductInfo = () => {
    if (isMobile) {
      setShowProductInfo(prev => !prev);
      if (!showProductInfo) setShowCategories(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header 
        toggleCategories={toggleCategories} 
        toggleProductInfo={toggleProductInfo} 
      />
      
      <main className="flex-grow max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 w-full">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Support Categories Sidebar */}
          {showCategories && (
            <div className="lg:w-1/4 space-y-4">
              <SupportCategories onClose={() => setShowCategories(false)} />
            </div>
          )}
          
          {/* Chat Interface */}
          <div className={`${showCategories && showProductInfo ? 'lg:w-2/4' : 'lg:w-3/4'} bg-white rounded-lg shadow`}>
            <ChatInterface />
          </div>
          
          {/* Product Info Sidebar */}
          {showProductInfo && (
            <div className="lg:w-1/4 space-y-4">
              <ProductInfo onClose={() => setShowProductInfo(false)} />
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
