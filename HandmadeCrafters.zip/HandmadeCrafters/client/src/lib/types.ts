export interface Category {
  id: number;
  name: string;
  icon: string;
  isActive: boolean;
}

export interface Message {
  id: number;
  sessionId: string;
  content: string;
  isBot: boolean;
  timestamp: string;
  intent?: string;
  responseId?: number;
}

export interface KnowledgeBase {
  id: number;
  intent: string;
  responses: string[];
  keywords?: string[];
  categoryId?: number;
}

export interface Feedback {
  id: number;
  messageId: number;
  rating: number;
  comment?: string;
  timestamp: string;
}

export interface Product {
  id: number;
  name: string;
  description: string;
  price: string;
  image: string;
  rating: string;
  reviewCount: number;
}

export interface Review {
  id: number;
  productId: number;
  username: string;
  rating: number;
  content: string;
  image?: string;
  verifiedPurchase: boolean;
  timestamp: string;
}

export interface ChatMessage {
  id: string;
  content: string;
  isBot: boolean;
  timestamp: string;
  images?: {
    url: string;
    alt: string;
    caption: string;
  }[];
}

export interface ChatContextType {
  sessionId: string;
  messages: ChatMessage[];
  isTyping: boolean;
  isLoadingMessages: boolean;
  messageInput: string;
  setMessageInput: (input: string) => void;
  selectedCategory: Category | null;
  setSelectedCategory: (category: Category | null) => void;
  sendMessage: (content: string) => void;
  connectToHuman: () => void;
  sendFeedback: (rating: number) => void;
}
