import { db } from "@db";
import { 
  categories, 
  messages, 
  knowledgeBase, 
  feedback, 
  products, 
  reviews 
} from "@shared/schema";
import { eq, desc, and } from "drizzle-orm";
import type { 
  MessageInsert, 
  FeedbackInsert,
  KnowledgeBase
} from "@shared/schema";

// Storage interface for database operations
export const storage = {
  // Categories
  getCategories: async () => {
    return db.query.categories.findMany({
      where: eq(categories.isActive, true),
    });
  },

  // Messages
  getMessagesBySessionId: async (sessionId: string) => {
    return db.query.messages.findMany({
      where: eq(messages.sessionId, sessionId),
      orderBy: messages.timestamp,
    });
  },

  createMessage: async (data: MessageInsert) => {
    const [message] = await db.insert(messages)
      .values(data)
      .returning();
      
    return message;
  },

  // Knowledge Base
  getResponseByIntent: async (intent: string): Promise<KnowledgeBase> => {
    const response = await db.query.knowledgeBase.findFirst({
      where: eq(knowledgeBase.intent, intent),
    });
    
    return response || null;
  },

  // Feedback
  createFeedback: async (data: FeedbackInsert) => {
    const [result] = await db.insert(feedback)
      .values(data)
      .returning();
      
    return result;
  },

  // Products
  getProducts: async () => {
    return db.query.products.findMany();
  },

  getProductById: async (id: number) => {
    return db.query.products.findFirst({
      where: eq(products.id, id),
    });
  },

  // Reviews
  getReviewsByProductId: async (productId: number) => {
    return db.query.reviews.findMany({
      where: eq(reviews.productId, productId),
      orderBy: desc(reviews.timestamp),
    });
  },
};
