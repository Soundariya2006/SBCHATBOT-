import natural from 'natural';
import { db } from "@db";
import { knowledgeBase } from "@shared/schema";

// Initialize NLP tools
const tokenizer = new natural.WordTokenizer();
const stemmer = natural.PorterStemmer;
const classifier = new natural.BayesClassifier();

// Initialize sentiment analyzer
const analyzer = new natural.SentimentAnalyzer('English', stemmer, 'afinn');

// Load the classifier with intents from the knowledge base
let isClassifierTrained = false;

async function initializeClassifier() {
  if (isClassifierTrained) return;
  
  try {
    // Get all intents from the knowledge base
    const intents = await db.query.knowledgeBase.findMany();
    
    if (intents.length === 0) {
      console.warn("No intents found in the knowledge base. Classifier will use defaults only.");
      
      // Add some default intents as fallback
      classifier.addDocument('hello hi hey greetings', 'greeting');
      classifier.addDocument('bye goodbye see you later farewell', 'farewell');
      classifier.addDocument('thank you thanks appreciate it', 'thanks');
      classifier.addDocument('help support assistance', 'help');
    } else {
      // Train the classifier with intents from the database
      intents.forEach(intent => {
        if (intent.keywords && intent.keywords.length > 0) {
          classifier.addDocument(intent.keywords.join(' '), intent.intent);
        }
      });
    }
    
    // Train the classifier
    classifier.train();
    isClassifierTrained = true;
    console.log("NLP classifier trained successfully");
  } catch (error) {
    console.error("Error training classifier:", error);
    throw error;
  }
}

// Initialize on first import
initializeClassifier().catch(console.error);

// Process text to extract intent
export async function classifyIntent(text: string): Promise<string | null> {
  try {
    // Make sure classifier is initialized
    if (!isClassifierTrained) {
      await initializeClassifier();
    }
    
    // Tokenize and stem the input text
    const tokens = tokenizer.tokenize(text.toLowerCase());
    if (!tokens || tokens.length === 0) {
      return null;
    }
    
    // Classify the intent
    const stemmed = tokens.map(token => stemmer.stem(token)).join(' ');
    const classification = classifier.classify(stemmed);
    
    return classification;
  } catch (error) {
    console.error("Error classifying intent:", error);
    return null;
  }
}

// Analyze sentiment of text
export async function analyzeSentiment(text: string): Promise<number> {
  try {
    const tokens = tokenizer.tokenize(text.toLowerCase());
    if (!tokens || tokens.length === 0) {
      return 0;
    }
    
    // Calculate sentiment score
    const sentiment = analyzer.getSentiment(tokens);
    return sentiment;
  } catch (error) {
    console.error("Error analyzing sentiment:", error);
    return 0;
  }
}
