import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { analyzeSentiment, classifyIntent } from "./nlp";
import { nanoid } from "nanoid";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API prefix
  const apiPrefix = "/api";

  // Get support categories
  app.get(`${apiPrefix}/categories`, async (req, res) => {
    try {
      const categories = await storage.getCategories();
      return res.status(200).json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      return res.status(500).json({ error: "Failed to fetch categories" });
    }
  });

  // Get chat history by session ID
  app.get(`${apiPrefix}/messages/:sessionId`, async (req, res) => {
    try {
      const { sessionId } = req.params;
      const messages = await storage.getMessagesBySessionId(sessionId);
      return res.status(200).json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      return res.status(500).json({ error: "Failed to fetch messages" });
    }
  });

  // Send a new message and get a response
  app.post(
    `${apiPrefix}/messages`,
    async (req, res) => {
      try {
        const messageSchema = z.object({
          sessionId: z.string(),
          content: z.string().min(1, "Message cannot be empty"),
        });

        const { sessionId, content } = messageSchema.parse(req.body);

        // Store user message
        const userMessage = await storage.createMessage({
          sessionId,
          content,
          isBot: false,
        });

        // Process message with NLP
        const intent = await classifyIntent(content);
        const sentiment = await analyzeSentiment(content);

        // Get appropriate response
        let response;
        if (intent) {
          response = await storage.getResponseByIntent(intent);
        }

        // If no intent recognized or no response found, use fallback
        if (!response) {
          response = await storage.getResponseByIntent("fallback");
        }

        // Select a random response from the available responses
        const responseContent = response.responses[
          Math.floor(Math.random() * response.responses.length)
        ];

        // Store bot response
        const botMessage = await storage.createMessage({
          sessionId,
          content: responseContent,
          isBot: true,
          intent,
          responseId: response.id,
        });

        return res.status(200).json({
          userMessage,
          botMessage,
          intent,
          sentiment,
        });
      } catch (error) {
        console.error("Error processing message:", error);

        if (error instanceof z.ZodError) {
          return res.status(400).json({ error: error.errors });
        }

        return res.status(500).json({ error: "Failed to process message" });
      }
    }
  );

  // Submit feedback on a bot message
  app.post(
    `${apiPrefix}/feedback`,
    async (req, res) => {
      try {
        const feedbackSchema = z.object({
          messageId: z.number(),
          rating: z.number().min(1).max(5),
          comment: z.string().optional(),
        });

        const validatedData = feedbackSchema.parse(req.body);
        const feedback = await storage.createFeedback(validatedData);

        return res.status(200).json(feedback);
      } catch (error) {
        console.error("Error submitting feedback:", error);

        if (error instanceof z.ZodError) {
          return res.status(400).json({ error: error.errors });
        }

        return res.status(500).json({ error: "Failed to submit feedback" });
      }
    }
  );

  // Get product information 
  app.get(`${apiPrefix}/products`, async (req, res) => {
    try {
      const products = await storage.getProducts();
      return res.status(200).json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      return res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  // Get product reviews
  app.get(`${apiPrefix}/products/:productId/reviews`, async (req, res) => {
    try {
      const { productId } = req.params;
      const productIdNumber = parseInt(productId, 10);
      
      if (isNaN(productIdNumber)) {
        return res.status(400).json({ error: "Invalid product ID" });
      }
      
      const reviews = await storage.getReviewsByProductId(productIdNumber);
      return res.status(200).json(reviews);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      return res.status(500).json({ error: "Failed to fetch reviews" });
    }
  });

  // Generate new session ID
  app.get(`${apiPrefix}/session`, (req, res) => {
    try {
      const sessionId = nanoid();
      return res.status(200).json({ sessionId });
    } catch (error) {
      console.error("Error generating session ID:", error);
      return res.status(500).json({ error: "Failed to generate session ID" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
