import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Support categories table
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  icon: text("icon").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
});

// Knowledge base for chatbot responses
export const knowledgeBase = pgTable("knowledge_base", {
  id: serial("id").primaryKey(),
  intent: text("intent").notNull().unique(),
  responses: text("responses").array().notNull(),
  keywords: text("keywords").array(),
  categoryId: integer("category_id").references(() => categories.id),
});

// User chat messages
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  content: text("content").notNull(),
  isBot: boolean("is_bot").default(false).notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  intent: text("intent"),
  responseId: integer("response_id").references(() => knowledgeBase.id),
});

// User feedback on chatbot responses
export const feedback = pgTable("feedback", {
  id: serial("id").primaryKey(),
  messageId: integer("message_id").references(() => messages.id).notNull(),
  rating: integer("rating").notNull(), // 1-5 rating scale
  comment: text("comment"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Product information for demonstration
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: text("price").notNull(),
  image: text("image").notNull(),
  rating: text("rating").notNull(),
  reviewCount: integer("review_count").notNull(),
});

// Product reviews
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").references(() => products.id).notNull(),
  username: text("username").notNull(),
  rating: integer("rating").notNull(),
  content: text("content").notNull(),
  image: text("image"),
  verifiedPurchase: boolean("verified_purchase").default(true).notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Relations
export const categoriesRelations = relations(categories, ({ many }) => ({
  knowledgeBase: many(knowledgeBase),
}));

export const knowledgeBaseRelations = relations(knowledgeBase, ({ one, many }) => ({
  category: one(categories, {
    fields: [knowledgeBase.categoryId],
    references: [categories.id],
  }),
  messages: many(messages),
}));

export const messagesRelations = relations(messages, ({ one, many }) => ({
  response: one(knowledgeBase, {
    fields: [messages.responseId],
    references: [knowledgeBase.id],
  }),
  feedback: many(feedback),
}));

export const productsRelations = relations(products, ({ many }) => ({
  reviews: many(reviews),
}));

export const reviewsRelations = relations(reviews, ({ one }) => ({
  product: one(products, {
    fields: [reviews.productId],
    references: [products.id],
  }),
}));

// Schemas
export const categoriesInsertSchema = createInsertSchema(categories);
export type CategoryInsert = z.infer<typeof categoriesInsertSchema>;
export type Category = typeof categories.$inferSelect;

export const knowledgeBaseInsertSchema = createInsertSchema(knowledgeBase);
export type KnowledgeBaseInsert = z.infer<typeof knowledgeBaseInsertSchema>;
export type KnowledgeBase = typeof knowledgeBase.$inferSelect;

export const messageInsertSchema = createInsertSchema(messages);
export type MessageInsert = z.infer<typeof messageInsertSchema>;
export type Message = typeof messages.$inferSelect;

export const feedbackInsertSchema = createInsertSchema(feedback);
export type FeedbackInsert = z.infer<typeof feedbackInsertSchema>;
export type Feedback = typeof feedback.$inferSelect;

export const productInsertSchema = createInsertSchema(products);
export type ProductInsert = z.infer<typeof productInsertSchema>;
export type Product = typeof products.$inferSelect;

export const reviewInsertSchema = createInsertSchema(reviews);
export type ReviewInsert = z.infer<typeof reviewInsertSchema>;
export type Review = typeof reviews.$inferSelect;

// Users schema (kept from template)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
